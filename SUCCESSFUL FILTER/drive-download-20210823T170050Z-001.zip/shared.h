#ifndef _SHARED_H
#define _SHARED_H

#include <string>
#include <vector>

//#define float double

bool readFile(const std::string fname,
		 std::vector<float> & results);

#endif
